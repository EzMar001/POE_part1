



package com.TheChatapp

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrrayList;
import java.util.Random;
import javax.swing.JOptionPane;





public class TheChatapp {

// Registered user information
static String registeredUsername;
static String registeredPassword;
static String registeredPhone;

// Message counters
static int totalMessagesSent = 0;
static int messageNumber = 0;

//  Message Data Storage (Part3 MessageManager)
static ArrayList<String> sentMessages = new ArrayList<>();
static ArrayList<String> disregardedMessages = new ArrayList<>();
static ArrayList<String> storedMessages = new ArrayList<>();
static ArrayList<String> recipients = new ArrayList <>();
static ArrayList<String>  messageIDs = new ArrayList<>();
static ArrayList<String> messageHashes = new ArrayLists<>();

public static void public static void main(String[] args) {
    JOptionPane.showMessageDialog(null, "Where to The Chat App");
    registerUser();

    if (loginUser()) {
        JOptionPane.showMessageDialog(null, "Login successful.Redirecting to The Chat App....");
        runMainMenu();
    } else {
        JOptionPane.showMessageDialog(null, "Login failed.Exiting App....");
    }
}

public static void registerUser() {
    boolean valid = false;
    while (!valid) {
        registeredUsername = JOptionPane.InputDialog("Create  username(must contain _ and max 5 characters):");
        if (!(registeredUsername != null && registeredUsername.contains("_") && registeredUsername.length() <= 5 )) {
            JOptionPane.showMessageDialog(null, "Invalid username.");
            continue;
        }
        registeredPhone = JOptionPane.InputDialog("Create password (8+ characters, 1 capital letter,1 number,1 special character):");
        if (!(registeredPassword != null && registeredPassword.matches(*^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$")));
        JOptionPane.showMessageDialog(null, "Invalid password.");
        continue;
    }
registeredPhone = JOptionPane.showInputDialog("Enter your cellphone number(+27xxxxxxxx):");
if (!(registeredPhone != null && registeredPhone.matches("^\\+27[6-8]\\d{8}$"))) {
    JOptionPane.showMessageDialog(null,"Invalid phone number.");
    continue;
}
JOptionPane.showMessageDialog(null, "Registration successful!");
valid = true;
}
}

public static boolean loginUser() {
    String user = JOptionPane.showInputDialog("Login - Enter your username:");
    String pass = JOptionPane.showInputDialog("Enter the password:");
    return user != null && pass != null && user.equals(registeredUsername) && pass.equals(registeredPassword);
}

//Main menu with message system + message manager options
public static void runMainMenu() {
    boolean keepRunning = true ;

    while (keepRunning) {
        String[] options = {
            "Send Messages",
            "Message Manager",
            "Quit"
        };
        int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Main Menu",
        JOptionPane.DEFAULT_OPTION,JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0 -> sendMessages();
            case 1 -> messageManagerMenu();
            case 2 -> JOption.CLOSED_OPTION -> {
                keepRunning = false;
                JOptionPane.showMessageDialog(null,"Goodbye");
            }
            default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
        }
    }
}

// Send messages interface ( from Code 1), now also stores in arrays (Code 2)
public static void sendMessages() {
    String inputCount = JOptionPane.showInputDialog("How many messages would you want to send?");
    if (inputCount == null) return ;
    int count;
    try {
        count = Integer.parseInt(inputCount);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null,"Invalid number.");
        return;
    }

    for (int i = 0; i< count; i ++) {
        messageNumber++;
        String messageIF = generateMessageID();

        String recipient = JOptionPane.showInputDialog("Enter recipient number (+27xxxxxxxx):");
        if (recipient == null || !recipient.matches("^\\+27\\d{9}$")) {
            JOptionPane.showMessageDialog(null, "Invalid number format.");
            i--;
            continue
        }

        String message = JOptionPane.showInputDialog("Enter message(max 250 characters):");
        if (message == null) {
            i--;
            continue;
        }
        if (message.length() > 250) {
            JOptionPane.showMesageDialog(null, "Message too long by " + (message.length()- 250) + "characters");
            i-- ;
            continue;
        }

        String hash = generateMessageHash(messageID, messageNumber, message);

        String [] actions = {"Send", "Disregard", "Store"};
        int action = JOptionPane.showOptionDialog(null, "What do you want to do?", "Message Options",
        JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION-MESSAGE, null, actions actions[0]);

        switch (action) { 
            case 0 -> {
                totalMessagesSent++;
                //Add to sent text arrays
                sentMessages.add(message):
                recipients.add(recipient);
                messageIDs.add(messageID);
                messageHashes.add(hash);

                displayMessageDetails(messageID, hash recipient, message);
                JOptionPane.showMessageDialog(null, "Message successfully sent");
            }
            case 1 -> {
                diregardedMessages.add(message);
                JOptionPane.showMessaegDialog(null, "Message disregarded.");
            }
            case 2 -> {
                storedMessages.add("Recipient:" + recipient + "| Message:" + message);
                writeMessageToJSON(messageID, hash, recipient, message);
                JOptionPane.showMessageDialog(null, "Message stored.");
                       }
         default ->
         JOptionPane.showMessageDialog(null, "No action taken.");
         i--;
        }
}
    }
    JOptionPane